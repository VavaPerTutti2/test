fx_version 'adamant'

game 'gta5'

client_scripts {
    'client/client.lua'
}

ui_page 'html/ui.html'

files {
    'html/ui.html',
    'html/img/image.png',
    'html/css/app.css',
    'html/scripts/app.js'
}
