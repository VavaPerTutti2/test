# cinematique
Sous la pression d'une touche, un mode cinématique (bande noire haut/bas et hud désactiver) apparaît.
